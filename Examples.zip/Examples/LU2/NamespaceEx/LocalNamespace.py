
def local_example():
    # this is an example of a variable contained
    # within a local namespace
    x = 5
    print(x)


local_example()

# this will not work because after we've ran local_example()
# everything within that namespace is wiped from memory
# print(x)
