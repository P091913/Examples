
my_list = ["I", "Am", "A", "List"]

# print and len are built-in namespaces,
# you always have access to them
print(len(my_list))
