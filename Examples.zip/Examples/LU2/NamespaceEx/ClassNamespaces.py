
class MyClass:
    # this variable is within my class namespace
    x = 20

    def __init__(self):
        # this variable is within my instance namespace
        self.x = 20


my_class = MyClass()
print(MyClass.x)
print(my_class.x)
