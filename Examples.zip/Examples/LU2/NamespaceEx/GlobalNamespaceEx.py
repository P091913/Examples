
# this is a global namespace example
x = 10


def use_global():
    print(x)
    

use_global()
