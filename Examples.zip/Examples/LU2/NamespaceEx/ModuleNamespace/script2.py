a = 2


def script_two():
    print("Script Two")
