import script1
import script2

# referencing global variables namespaces within the modules
# namespaces
print(script1.a)
print(script2.a)


# call functions within my module namespaces
script1.script_one()
script2.script_two()
