a = 1


def script_one():
    print("Script One")

