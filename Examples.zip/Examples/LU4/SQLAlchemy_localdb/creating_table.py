from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

# Define the database connection
engine = create_engine('sqlite:///phone_cases.db', echo=True)  # echo=True for debugging

# Create a base class that our models will inherit
Base = declarative_base()


# Define the PhoneCase model
class PhoneCase(Base):
    __tablename__ = 'phone_cases'

    id = Column(Integer, primary_key=True)
    brand = Column(String)
    model = Column(String)
    color = Column(String)
    material = Column(String)
    price = Column(Integer)
    quantity = Column(Integer)


# Create the table in the database
Base.metadata.create_all(engine)

# Example usage to add a phone case to the database
if __name__ == "__main__":
    # Create a session to interact with the database
    Session = sessionmaker(bind=engine)
    session = Session()

    # Example: Adding a phone case
    new_phone_case = PhoneCase(brand='Apple', model='iPhone 12', color='Black',
                               material='Silicone', price=29, quantity=50)

    session.add(new_phone_case)
    session.commit()

    # Close the session
    session.close()
