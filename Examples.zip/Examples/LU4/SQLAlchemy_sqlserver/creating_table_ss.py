from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Define the database connection
# Replace 'mssql' with 'mssql+pyodbc' if using PyODBC driver
# Replace 'localhost' with your SQL Server hostname or IP address
# Replace 'database_name' with your actual database name
# Replace 'username' and 'password' with your credentials
# Define the connection parameters
server = 'localhost'
database = 'class_primary'
username = 'root'
password = 'passowrd'

# Create the connection string
connection_string = f'mssql+pyodbc://{username}:{password}@{server}/{database}?driver=SQL+Server'

# Set up the SQLAlchemy engine
engine = create_engine(connection_string)
# Create a base class that our models will inherit
Base = declarative_base()


# Define the PhoneCase model
class PhoneCase(Base):
    __tablename__ = 'phone_cases'

    id = Column(Integer, primary_key=True)
    brand = Column(String)
    model = Column(String)
    color = Column(String)
    material = Column(String)
    price = Column(Integer)
    quantity = Column(Integer)


# Create the table in the database
Base.metadata.create_all(engine)

# Example usage to add a phone case to the database
if __name__ == "__main__":
    # Create a session to interact with the database
    Session = sessionmaker(bind=engine)
    session = Session()

    # Example: Adding a phone case
    new_phone_case = PhoneCase(brand='Apple', model='iPhone 12', color='Black',
                               material='Silicone', price=29, quantity=50)

    session.add(new_phone_case)
    session.commit()

    # Close the session
    session.close()
