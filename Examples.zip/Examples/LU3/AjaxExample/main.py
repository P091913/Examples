from flask import Flask, render_template, flash, session, redirect, url_for, request, jsonify

app = Flask(__name__)
app.secret_key="fher84D"


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = data.get('username')
    passwd = data.get('password')

    if not user or not passwd:
        return jsonify({'success': False, 'error': 'Invalid username or password'})

    # Here you can add additional logic for validating the user
    # For example, check against a database

    return jsonify({'success': True, 'user': user})


if __name__ == '__main__':
    app.run(debug=True)
