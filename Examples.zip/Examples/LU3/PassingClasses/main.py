from flask import Flask, render_template, flash, session, redirect, url_for, request
from models import User
app = Flask(__name__)
app.secret_key="fher84D"




@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['POST'])
def login():

    my_user = User(request.form['username'], request.form['password'])
    user = request.form['username']
    passwd = request.form['password']

    if user == "" or passwd == "":
        flash('Invalid username or password')
    else:
        session['username'] = user
        session['password'] = passwd

    return render_template("login.html")


if __name__ == '__main__':
    app.run(debug=True)
