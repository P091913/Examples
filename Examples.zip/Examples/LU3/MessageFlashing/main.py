from flask import Flask, render_template, flash, session, redirect, url_for, request

app = Flask(__name__)
app.secret_key="fher84D"


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['POST'])
def login():
    user = request.form['username']
    passwd = request.form['password']

    if user == "" or passwd == "":
        flash('Invalid username or password')
        return redirect(url_for('index'))
    else:
        return render_template("login.html", user=user, password=passwd)


if __name__ == '__main__':
    app.run(debug=True)
