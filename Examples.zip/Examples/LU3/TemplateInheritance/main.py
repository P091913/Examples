from flask import Flask, render_template, request, flash, session, redirect, url_for

app = Flask(__name__)
app.secret_key="fher84D"


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    if username == 'jarrett' and password == 'password':
        session['username'] = username
        return redirect(url_for('social'))
    else:
        flash('Invalid username or password')

    return render_template('index.html')

@app.route("/social")
def social():
    username = session.get('username')
    if username:
        return render_template("social.html")


if __name__ == '__main__':
    app.run(debug=True)